
export class Alumno {

    constructor (
       public nombre: string,
       public edad: number, 
       public curso:string
    ) {}
}

